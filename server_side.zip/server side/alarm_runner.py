import pytse_client as tse_client
from sqlite3 import connect
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from base64 import urlsafe_b64encode
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from mimetypes import guess_type as guess_mime_type
import pickle, os


def get_datas_of_a_stock(stock_name, data):
    ticker = tse_client.Ticker(stock_name)
    match data:
        case 'history':
            return ticker.history
        case 'title':
            return ticker.title
        case 'url':
            return ticker.url
        case 'group_name':
            return ticker.group_name
        case 'eps':
            return ticker.eps
        case 'p_e_ratio':
            return ticker.p_e_ratio
        case 'group_p_e_ratio':
            return ticker.group_p_e_ratio
        case 'base_volume':
            return ticker.base_volume
        case 'last_price':
            return ticker.last_price
        case 'adj_close':
            return ticker.adj_close


def get_alarms():
    global USERNAME, ALARMS_FILE
    alarms_db = connect('alarms.db')
    cursor = alarms_db.cursor()
    cursor.execute("SELECT * FROM ?", (ALARMS_FILE,))
    alarms = cursor.fetchall()
    alarms_db.close()
    return alarms


def progress_data(data):
    try:
        return int(data)
    except:
        stock_name_and_attribute = data.replace('stock[', '')
        stock_name_and_attribute = stock_name_and_attribute.replace(']', '')
        stock_name, attribute = stock_name_and_attribute.split('.')
        return get_datas_of_a_stock(stock_name, attribute)


def call(phone_number, text):
    pass


def send_sms(phone_number, text):
    pass


def send_telegram_message(id, text):
    pass


def send_email(email_address, text):
    def send_email(receiver, subject, text, attachments=[], sender_email='SOLA.mail.python@gmail.com', number=1):
        SCOPES = ['https://mail.google.com/']
        our_email = sender_email

        def add_attachment(message, filename):
            content_type, encoding = guess_mime_type(filename)
            if content_type is None or encoding is not None:
                content_type = 'application/octet-stream'
            main_type, sub_type = content_type.split('/', 1)
            if main_type == 'text':
                fp = open(filename, 'rb')
                msg = MIMEText(fp.read().decode(), _subtype=sub_type)
                fp.close()
            elif main_type == 'image':
                fp = open(filename, 'rb')
                msg = MIMEImage(fp.read(), _subtype=sub_type)
                fp.close()
            elif main_type == 'audio':
                fp = open(filename, 'rb')
                msg = MIMEAudio(fp.read(), _subtype=sub_type)
                fp.close()
            else:
                fp = open(filename, 'rb')
                msg = MIMEBase(main_type, sub_type)
                msg.set_payload(fp.read())
                fp.close()
            filename = os.path.basename(filename)
            msg.add_header('Content-Disposition', 'attachment', filename=filename)
            message.attach(msg)

        def send_message(service, destination, obj, body, attachments=[]):
            return service.users().messages().send(
                userId="me",
                body=build_message(destination, obj, body, attachments)
            ).execute()

        def build_message(destination, obj, body, attachments=[]):
            if not attachments:  # no attachments given
                message = MIMEText(body)
                message['to'] = destination
                message['from'] = our_email
                message['subject'] = obj
            else:
                message = MIMEMultipart()
                message['to'] = destination
                message['from'] = our_email
                message['subject'] = obj
                message.attach(MIMEText(body))
                for filename in attachments:
                    add_attachment(message, filename)
            return {'raw': urlsafe_b64encode(message.as_bytes()).decode()}

        def gmail_authenticate(json_filename, token_file):
            creds = None
            # the file token.pickle stores the user's access and refresh tokens, and is
            # created automatically when the authorization flow completes for the first time
            if os.path.exists(token_file):
                with open(token_file, "rb") as token:
                    creds = pickle.load(token)
            # if there are no (valid) credentials available, let the user log in.
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(json_filename, SCOPES)
                    creds = flow.run_local_server(port=0)
                # save the credentials for the next run
                with open(token_file, "wb") as token:
                    pickle.dump(creds, token)
            return build('gmail', 'v1', credentials=creds)

        # get the Gmail API service
        service = gmail_authenticate('../../../gmail_api_data/sola_credentials.json',
                                     '../../../gmail_api_data/sola_token.pickle')
        for num in range(0, number):
            send_message(service, receiver, subject, text, attachments)


def run_alarms():
    global USERNAME, ALARMS_FILE
    alarms_ = get_alarms()
    for alarm_ in alarms_:
        alarm = alarm_[1]
        do_not_run_commands = False
        alarm_items = alarm.replace('IF ')
        alarm_items = alarm_items.split('=>')
        alarm_ifs = alarm_items[0].split(',')
        commands = alarm_items[1].split(',')
        alarm_ifs.pop(-1)
        for alarm_if in alarm_ifs:
            if_items = alarm_if.split(':')
            data1 = progress_data(if_items[0])
            operator = if_items[1]
            data2 = progress_data(if_items[2])
            if operator == '>' and data1 > data2:
                pass
            elif operator == '<' and data1 < data2:
                pass
            elif operator == '==' and data1 == data2:
                pass
            elif operator == '<=' and data1 <= data2:
                pass
            elif operator == '>=' and data1 >= data2:
                pass
            elif operator == '!=' and data1 != data2:
                pass
            else:
                do_not_run_commands = True
                break
        if not do_not_run_commands:
            db_alarms = connect('alarms.db')
            cursor_alarms = db_alarms.cursor()
            db = connect('DataBase.db')
            cursor = db.cursor()
            cursor.execute(f"SELECT phone,telegram_id,email FROM users WHERE username='{USERNAME}'")
            phone, telegram_id, email = cursor.fetchall()[0]
            for command in commands:
                if command == 'send_sms':
                    send_sms(phone, 'هشدار! هشدار! یکی از شرط هایی که تعریف کرده بودید فعال شده است! سهام مدنظر خود را بررسی کنید')
                if command == 'call':
                    call(phone, 'یکی از شرط هایی که تعریف کرده بودید فعال شده است!')
                if command == 'send_telegram_message':
                    send_telegram_message(telegram_id, 'check your stocks => one of alarms turned on!')
                if command == 'send_email':
                    send_email(email, 'هشدار! هشدار! یکی از شرط هایی که تعریف کرده بودید فعال شده است! سهام مدنظر خود را بررسی کنید')
            cursor_alarms.execute(f"UPDATE '{ALARMS_FILE}' SET turn='off' WHERE id={alarm_[0]}")
            db_alarms.commit()
            db_alarms.close()
            db.close()


if __name__ == '__main__':
    while True:
        run_alarms()

