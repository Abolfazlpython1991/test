BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "users" (
	"id"	INTEGER NOT NULL,
	"username"	VARCHAR(60) NOT NULL,
	"password"	VARCHAR(60) NOT NULL,
	"alarms_file"	str NOT NULL,
	"phone"	str NOT NULL,
	"telegram_id"	str,
	"email"	str,
	PRIMARY KEY("id" AUTOINCREMENT)
);
COMMIT;
